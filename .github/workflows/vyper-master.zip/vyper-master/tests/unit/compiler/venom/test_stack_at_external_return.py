def test_stack_at_external_return():
    """
    TODO: USE BOA DO GENERATE THIS TEST
    """
    pass
