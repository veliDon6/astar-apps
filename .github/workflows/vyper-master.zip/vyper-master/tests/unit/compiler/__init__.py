# prevent module name collision between tests/compiler/test_pre_parser.py
# and tests/ast/test_pre_parser.py
