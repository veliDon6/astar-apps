NONREENTRANT_NOTE = (
    "\n  note that use of the `@nonreentrant` decorator is also considered state access"
)
